
int debug_print(const char *f,...);
