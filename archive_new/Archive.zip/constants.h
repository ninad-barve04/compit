#ifndef CONSTANTS_H
#define CONSTANTS_H (1)

#define BUFFER_SIZE (256)

#define ENCODING_BUFFER (4)

#define HALF (0.5)
#define FIRST_QUARTER (0.25)
#define THIRD_QUARTER (0.75)

#endif // CONSTANTS_H
