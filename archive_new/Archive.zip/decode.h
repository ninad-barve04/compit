#ifndef DECODE_H
#define DECODE_H (1)

void decode_file(FILE *encoded, FILE *decoded);

#endif // DECODE_H
